public interface DapatDiNilai {
    void beriRating(int rating);
}